package com.example.birdmodelcreation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class eyes_selection extends AppCompatActivity {

    public EyesData[] myEyesData;
    private RecyclerView recyclerView;
    private EyesAdapter.RecyclerViewClickListener listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eyes_selection);
        recyclerView = findViewById(R.id.recyclerView_eyes);

        setAdapter();
    }



    private void setOnClickListener(){

        listener = new EyesAdapter.RecyclerViewClickListener() {
            @Override
            public void onClick(View v, int position) {
                int selectedEyesImage = myEyesData[position].getEyesImage();

                String selectedEyesDescription = myEyesData[position].getEyesDescription();

                // System.out.println(selectedBeakDescription);
                Intent resultIntent = new Intent();
                resultIntent.putExtra("SelectedEyes", selectedEyesImage);

                setResult(RESULT_OK, resultIntent);
                finish();

            }
        };




    }



    private void setAdapter(){



        setOnClickListener();
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        //  list.add(new com.example.birdmodelcreation.BeakData("Generalist ",R.drawable.generalist));
        myEyesData = new EyesData[]{
                new  EyesData("Normal Eyes",R.drawable.birds_eyes),
                /*  new  HeadData("Deep Netting",R.drawable.deep_netting),*/
                /*  new BeakData("Fruit Eating/ Scavenging",R.drawable.fruit_eating),
                  new BeakData("Surface Skimming",R.drawable.surface_skimming),
                  new  BeakData("Coniferous Seed Eating",R.drawable.coniferous_seed_eating),
                  new  BeakData("Probing/ Nectar Feeding",R.drawable.probing),
                  new  BeakData("Mud Probing",R.drawable.mud_probing),
                  new  BeakData("Filter Feeding",R.drawable.filter_feeding),
                  new  BeakData("Insect Catching/ Aerial Fishing/ Pursuit Fishing/ Chiseling",R.drawable.insect_catching),*/

                //  new  BeakData("Avatar",R.drawable.avatar),
        };

        EyesAdapter myEyesAdapter = new EyesAdapter(myEyesData,eyes_selection.this, listener);
        recyclerView.setAdapter(myEyesAdapter);


    }
}